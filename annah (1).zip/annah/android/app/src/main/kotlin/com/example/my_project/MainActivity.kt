package com.mycompany.annah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
